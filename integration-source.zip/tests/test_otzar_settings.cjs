'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const script = fs.readFileSync(__dirname + '/../plugin/settings.js', 'utf8');
async function run(saved, failLoad = false) {
  const nodes = { target: { value: 'local' }, save: { disabled: true }, status: {} };
  const events = {}, writes = [];
  const css = new Map();
  const style = { setProperty(name, value) { css.set(name, value); } };
  let click, failSave = false;
  nodes.save.addEventListener = (name, fn) => { assert.equal(name, 'click'); click = fn; };
  vm.runInNewContext(script, {
    document: { documentElement: { style }, getElementById(id) { return nodes[id]; } },
    Otzaria: { on(name, fn) { events[name] = fn; }, async call(method, params) {
      assert.equal(params.key, 'otzar_open_target');
      if (method === 'storage.get') return { success: !failLoad, data: saved };
      assert.equal(method, 'storage.set');
      writes.push(params.value);
      return { success: !failSave };
    } },
  });
  events['plugin.boot']({ theme: { mode: 'dark', colorScheme: {
    surface: '#111111', onSurface: '#eeeeee', outline: '#777777' },
    surfaces: { panel: '#222222', card: '#333333' },
    typography: { uiFont: 'system-ui' }, radius: 8 } });
  assert.equal(style.colorScheme, 'dark');
  assert.equal(css.get('--color-background'), '#222222');
  assert.equal(css.get('--color-control-background'), '#333333');
  assert.equal(css.get('--font-base'), 'system-ui');
  assert.equal(css.get('--radius'), '8px');
  events['theme.changed']({ mode: 'light', colorScheme: {
    surface: '#ffffff', onSurface: '#111111', outline: '#888888' } });
  assert.equal(style.colorScheme, 'light');
  assert.equal(css.get('--color-background'), '#ffffff');
  assert.equal(css.get('--color-text'), '#111111');
  events['plugin.ready']();
  await new Promise(resolve => setImmediate(resolve));
  if (failLoad) {
    assert.equal(nodes.save.disabled, true);
    assert.match(nodes.status.textContent, /לא ניתן לטעון/);
    return;
  }
  assert.equal(nodes.target.value, ['local', 'online', 'auto'].includes(saved) ? saved : 'local');
  assert.equal(nodes.save.disabled, false);
  for (const choice of ['local', 'online', 'auto']) {
    nodes.target.value = choice;
    await click();
    assert.equal(writes.at(-1), choice);
    assert.equal(nodes.save.disabled, false);
    assert.match(nodes.status.textContent, /נשמרה/);
  }
  failSave = true;
  await click();
  assert.match(nodes.status.textContent, /לא ניתן לשמור/);
  assert.equal(nodes.save.disabled, false);
}
(async () => {
  for (const saved of [null, 'local', 'online', 'auto', 'invalid']) await run(saved);
  await run(null, true);
  console.log('PASS: host theme changes, local default, saved destination restored, all choices persisted, load/save failures visible');
})().catch(error => { console.error(error); process.exitCode = 1; });
