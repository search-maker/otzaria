'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const script = fs.readFileSync(__dirname + '/../plugin/main.js', 'utf8');
const manifest = JSON.parse(fs.readFileSync(__dirname + '/../plugin/manifest.json', 'utf8'));
const events = {}, calls = [], replies = [], errors = [], opened = [];
let rows = [
  { book_id: 9448, title: 'מהר"ם שיק', authors: '["משה שיק"]', places: 'מונקץ', from_year: 'תר"מ' },
  { book_id: 9679, title: 'מהר"ם שיק', authors: '["משה שיק"]', places: 'סטו מרה', from_year: 'תר"צ' },
  { book_id: 12070, title: 'מהר"ם שיק', authors: '["משה שיק"]', places: 'מונקץ', from_year: 'תר"מ' },
  { book_id: 99, title: 'מַהֲר״ם שיק — ליקוטים', authors: 'broken' },
  { book_id: 45, title: 'קצות־החושן', authors: '[]' },
];
let gate = null, fail = false, openResult = true, target = 'auto', localAvailable = true;
const localOpened = [], onlineOpened = [];
function match(row, condition) {
  if (condition.op === 'and') return condition.conditions.every(c => match(row, c));
  const value = row[condition.left.split('.')[1]];
  if (condition.op === '=') return value === condition.value;
  if (condition.op === 'in') return condition.value.includes(value);
  assert.equal(condition.op, 'like');
  const pattern = condition.value.split('%').map(s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('.*');
  return new RegExp('^' + pattern + '$', 'iu').test(value);
}
const context = { console: { log() {}, error() {} }, Otzaria: {
  on(name, fn) { events[name] = fn; },
  async call(method, params) {
    calls.push({ method, params });
    if (method === 'storage.get') return { success: true, data: target };
    if (method === 'app.openUrl') { onlineOpened.push(params); return { success: true, data: true }; }
    if (method === 'network.fetchStream') {
      const url = new URL(params.url);
      let body;
      if (url.pathname === '/health') {
        body = { service: 'otzaria-responsa', apiVersion: 1,
          capabilities: localAvailable ? ['otzarOpen'] : ['referenceResolve'] };
      } else {
        assert.equal(url.pathname, '/otzar/open');
        assert.equal(params.method, 'POST');
        const selection = JSON.parse(params.body);
        localOpened.push(selection);
        body = { opened: true, target: 'local', bookId: selection.bookId };
      }
      return (async function* () {
        yield { type: 'response', status: 200 };
        yield { type: 'data', body: JSON.stringify(body) };
      })();
    }
    if (method === 'reader.respondFindRef') { replies.push(params); return { success: true, data: true }; }
    if (method === 'ui.showError') { errors.push(params); return { success: true }; }
    if (method === 'reader.openBook') { opened.push(params); return { success: true, data: openResult }; }
    assert.equal(method, 'database.query');
    assert.equal(params.sourceId, 'external_catalog');
    assert.equal(params.from.table, 'otzar_hahochma');
    assert.equal(params.from.alias, 'b');
    assert.ok(params.select.length <= 8 && params.limit <= 1000);
    assert.equal(params.rowFormat, 'object');
    assert.equal(params.orderBy.map(o => o.expr).join(','), 'b.book_id');
    if (gate) await gate;
    if (fail) return { success: false, error: { code: 'database.unavailable' } };
    return { success: true, data: { rows: rows.filter(r => match(r, params.where))
      .sort((a, b) => a.book_id - b.book_id).slice(0, params.limit) } };
  },
} };
vm.createContext(context); vm.runInContext(script, context);
const wait = async fn => { for (let i = 0; i < 100; i++) { if (fn()) return; await new Promise(r => setTimeout(r, 2)); } throw Error('Timed out'); };
const search = (id, query) => events['findRef.external.requested']({ provider: 'catalogfindref', requestId: id, query });
const select = (query, index, reference) => events['findRef.external.openRequested']({ provider: 'catalogfindref', query, choiceIndex: index, expectedChoice: reference });
(async () => {
  assert.ok(manifest.permissions.includes('database.read'));
  assert.ok(manifest.name.trim().length <= 14);
  assert.ok(manifest.description.trim().length <= 150);
  assert.equal(manifest.contributes.toolTab.title, manifest.name);
  assert.ok(manifest.permissions.includes('network.access'));
  assert.ok(manifest.network.allowlist.includes('https://tablet.otzar.org'));
  assert.equal(manifest.permissions.includes('network.internet'), false);
  assert.equal(manifest.contributes.startup.libraryBooks.filter(p => p.referenceSearch).length, 2);
  // Native Otzaria reserves provider names containing built-in catalog names.
  for (const provider of manifest.contributes.startup.libraryBooks) {
    assert.doesNotMatch(provider.provider, /otzar|otzaria|hebrewbooks|(?:hb|hebrew|otz|oh):/i);
  }
  search('one', 'מהרם שיק'); await wait(() => replies.length === 1);
  const first = replies[0].results;
  assert.equal(first.length, 4);
  assert.equal(new Set(first.map(r => r.reference)).size, 4);
  assert.equal(opened.length, 0);
  assert.equal(calls.some(c => c.method === 'network.fetchStream'), false);
  assert.match(first[0].reference, /9448/);
  assert.match(first[1].reference, /9679/);
  select('מהרם שיק', 1, first[1].reference); await wait(() => opened.length === 1);
  assert.equal(opened[0].external.provider, 'otzar');
  assert.equal(opened[0].external.id, 9679);
  // Same title and publication data, different immutable book ID.
  select('מהרם שיק', 2, first[2].reference); await wait(() => opened.length === 2);
  assert.equal(opened[1].external.id, 12070);
  select('מהרם שיק', 0, first[1].reference); await wait(() => errors.length === 1);
  assert.equal(opened.length, 2);
  rows = rows.filter(r => r.book_id !== 9448);
  select('מהרם שיק', 0, first[0].reference); await wait(() => errors.length === 2);
  assert.equal(opened.length, 2);
  search('hyphen', 'קצות החושן'); await wait(() => replies.length === 2);
  assert.equal(replies[1].results.length, 1);
  assert.equal(opened.length, 2); // A singleton never opens automatically.
  search('empty', '% _'); await wait(() => replies.length === 3);
  assert.equal(replies[2].results.length, 0);
  search('absent', 'ספר שאינו קיים'); await wait(() => replies.length === 4);
  assert.equal(replies[3].results.length, 0);
  fail = true; search('failure', 'מהרם שיק'); await wait(() => replies.length === 5);
  assert.equal(replies[4].results.length, 0); assert.ok(replies[4].error);
  fail = false;
  let release; gate = new Promise(r => { release = r; });
  search('cancel', 'מהרם שיק');
  events['findRef.external.cancelled']({ requestId: 'cancel' });
  gate = null; release();
  await new Promise(r => setTimeout(r, 10));
  assert.equal(replies.some(r => r.requestId === 'cancel'), false);
  const before = replies.length; search('one', 'מהרם שיק');
  await new Promise(r => setTimeout(r, 10)); assert.equal(replies.length, before);
  rows = Array.from({ length: 70 }, (_, i) => ({ book_id: i + 1, title: 'ספר בדיקה ' + i, authors: '[]' }));
  search('limit', 'ספר בדיקה'); await wait(() => replies.length === 6);
  assert.equal(replies[5].results.length, 40);
  // Opening also works after a headless runtime has lost its in-memory cache.
  vm.runInContext('otzarSnapshots.clear()', context);
  select('ספר בדיקה', 3, replies[5].results[3].reference); await wait(() => opened.length === 3);
  assert.equal(opened[2].external.id, 4);
  openResult = false;
  select('ספר בדיקה', 3, replies[5].results[3].reference); await wait(() => errors.length === 3);
  select('ספר בדיקה', -1, replies[5].results[3].reference);
  await new Promise(r => setTimeout(r, 10)); assert.equal(opened.length, 4);
  target = null; // The default must open locally, without silently opening a browser.
  select('ספר בדיקה', 3, replies[5].results[3].reference);
  await wait(() => localOpened.length === 1);
  assert.deepEqual(localOpened[0], { bookId: 4, page: 1 });
  assert.equal(onlineOpened.length, 0);
  assert.equal(opened.length, 4);
  target = 'online';
  select('ספר בדיקה', 3, replies[5].results[3].reference);
  await wait(() => onlineOpened.length === 1);
  assert.equal(onlineOpened[0].url, 'https://tablet.otzar.org/book/book.php?book=4');
  assert.equal(localOpened.length, 1);
  target = 'local'; localAvailable = false;
  select('ספר בדיקה', 3, replies[5].results[3].reference);
  await wait(() => errors.length === 4);
  assert.equal(localOpened.length, 1);
  assert.equal(onlineOpened.length, 1);
  assert.equal(opened.length, 4);
  console.log('PASS: Otzar offline search, normalized titles, exact edition IDs, passive singleton, mismatch/deletion guards, cancellation, bounded results, restart recovery, open failure');
})().catch(e => { console.error(e); process.exitCode = 1; });
