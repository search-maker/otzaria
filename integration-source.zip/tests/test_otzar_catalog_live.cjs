'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const { execFileSync } = require('node:child_process');
const [python, database] = process.argv.slice(2);
if (!python || !database) throw Error('Usage: node test_otzar_catalog_live.cjs <python.exe> <catalog.db>');
const pythonQuery = `import json,sqlite3,sys
q=json.load(sys.stdin)
params=[]
columns={'book_id','title','authors','places','from_year','to_year'}
def column(ref):
    assert ref.startswith('b.') and ref[2:] in columns
    return ref
def condition(c):
    op=c['op']
    if op=='and': return '('+' AND '.join(condition(x) for x in c['conditions'])+')'
    ref=column(c['left'])
    if op=='in':
        params.extend(c['value'])
        return ref+' IN ('+','.join('?' for x in c['value'])+')'
    assert op in ('=','like')
    params.append(c['value'])
    return ref+' '+op+' ?'
sql='SELECT '+','.join(column(c['expr']) for c in q['select'])+' FROM otzar_hahochma b WHERE '+condition(q['where'])+' ORDER BY b.book_id LIMIT ?'
params.append(q['limit'])
c=sqlite3.connect('file:'+sys.argv[1].replace('\\\\','/')+'?mode=ro',uri=True)
c.row_factory=sqlite3.Row
print(json.dumps({'rows':[dict(r) for r in c.execute(sql,params)]},ensure_ascii=False))
`;
const events = {}, replies = [], opened = [];
const context = { console, Otzaria: {
  on(name, fn) { events[name] = fn; },
  async call(method, params) {
    if (method === 'storage.get') return { success: true, data: 'auto' };
    if (method === 'database.query') return { success: true, data: JSON.parse(execFileSync(python, ['-X', 'utf8', '-c', pythonQuery, database], { input: JSON.stringify(params), encoding: 'utf8' })) };
    if (method === 'reader.respondFindRef') { replies.push(params); return { success: true, data: true }; }
    if (method === 'reader.openBook') { opened.push(params); return { success: true, data: true }; }
    throw Error('Unexpected method ' + method);
  },
} };
vm.createContext(context);
vm.runInContext(fs.readFileSync(__dirname + '/../plugin/main.js', 'utf8'), context);
(async () => {
  await vm.runInContext("handleSearch({provider:'catalogfindref',requestId:'real-1',query:'מהרם שיק'})", context);
  assert.ok(replies[0].results.length >= 3 && replies[0].results.length <= 40);
  assert.equal(replies[0].error, undefined);
  assert.equal(opened.length, 0);
  const index = replies[0].results.findIndex(r => r.reference.endsWith('(מס׳ 9679)'));
  assert.ok(index >= 0);
  context.selection = { provider: 'catalogfindref', query: 'מהרם שיק', choiceIndex: index, expectedChoice: replies[0].results[index].reference };
  await vm.runInContext('handleOpen(selection)', context);
  assert.equal(opened[0].external.id, 9679);
  console.log(JSON.stringify({ passed: true, catalogQuery: 'מהרם שיק', hits: replies[0].results.length, exactSelectedId: opened[0].external.id, reference: replies[0].results[index].reference, readerOpenStubbed: true }));
})().catch(e => { console.error(e); process.exitCode = 1; });
