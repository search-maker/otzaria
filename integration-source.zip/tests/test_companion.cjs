'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const script = fs.readFileSync(__dirname + '/../plugin/main.js', 'utf8');
const events = {};
let health = { service: 'otzaria-responsa', apiVersion: 1, capabilities: ['referenceResolve'] };
let matches = ['תלמוד בבלי מסכת ברכות דף ב עמוד א', 'רש"י מסכת ברכות דף ב עמוד א'];
let calls = [];
let replies = [];
function respond(data) {
  const target = JSON.parse(data || '{}');
  if (target.listOnly) {
    assert.equal(target.autoStart, false);
    assert.equal(target.index, undefined);
    return { ok: true, opened: false, choices: matches };
  }
  assert.equal(typeof target.index, 'number');
  assert.equal(target.expectedChoice, matches[target.index]);
  return { ok: true, opened: true };
}
let openOutcome = respond;
let missing = false;
const context = {
  Otzaria: {
    on(topic, cb) {events[topic] = cb;},
    call(method, data) {
      calls.push({ method, data });
      if (method === 'reader.respondFindRef') {replies.push(data); return {success:true, data:true};}
      assert.equal(method, 'network.fetchStream');
      const match = data.url.match(/:(\d+)(\/.*)$/);
      const path = match[2];
      if (missing || (path !== '/health' && path !== '/reference/open')) {
        return (async function* (){yield{type:'response',status:404};yield{type:'data',body:'{}'};})();
      }
      const value = path === '/health' ? health : openOutcome(data.body);
      return Promise.resolve((async function* (){
        yield { type: 'response', status: 200 };
        yield { type: 'data', body: JSON.stringify(value) };
      })());
    }
  }, console,
};
vm.createContext(context);
vm.runInContext(script, context);
assert.equal(typeof events['findRef.external.requested'], 'function');
assert.equal(typeof events['findRef.external.openRequested'], 'function');
function waitUntil(fn, ms = 600) {return new Promise((resolve, reject)=> {const t = Date.now();function loop(){if(fn())resolve(); else if(Date.now()-t>ms)reject(new Error('timed out')); else setTimeout(loop, 3)}loop()})}
(async () => {
  // 1. Passive reference search, unique result, without opening any book.
  matches = ['ספר בראשית פרק א פסוק ב'];
  events['findRef.external.requested']({requestId:'r1', provider:'barilanfindref', query:'בראשית א ב'});
  await waitUntil(() => replies.length === 1);
  assert.equal(replies[0].results.length, 1);
  assert.equal(replies[0].results[0].reference, matches[0]);
  assert.equal(calls.filter(x=>x.data?.url?.endsWith('/reference/open')).length, 1);
  assert.equal(JSON.parse(calls.find(x=>x.data?.url?.endsWith('/reference/open')).data.body).listOnly, true);

  // 2. A selected exact result is opened ONLY with expectedChoice.
  events['findRef.external.openRequested']({provider:'barilanfindref',query:'בראשית א ב',choiceIndex:0,expectedChoice:matches[0]});
  await waitUntil(() => calls.filter(x=>x.data?.url?.endsWith('/reference/open')).length === 2);
  assert.equal(JSON.parse(calls.at(-1).data.body).expectedChoice, matches[0]);

  // 3. Changed ordering: an exact textual match is relocated, never guessed.
  matches=['פירוש', 'ספר בראשית פרק א פסוק ב'];
  let seen=0;
  openOutcome=(body)=>{const params=JSON.parse(body); seen++;
    if(seen===1) {assert.equal(params.index,0); return {ok:true,opened:false,choices:matches}}
    assert.equal(params.index,1);assert.equal(params.expectedChoice,matches[1]);return {ok:true,opened:true};};
  events['findRef.external.openRequested']({provider:'barilanfindref',query:'בראשית א ב',choiceIndex:0,expectedChoice:matches[1]});
  await waitUntil(()=>seen===2);

  // 4. Consecutive typed queries: stale queued requests are not sent to Responsa.
  openOutcome=respond;
  const beforeCalls=calls.filter(x=>x.data?.url?.endsWith('/reference/open')).length;
  const beforeReplies=replies.length;
  events['findRef.external.requested']({requestId:'r-fast-1',provider:'barilanfindref',query:'ברכות ב'});
  events['findRef.external.cancelled']({requestId:'r-fast-1'});
  events['findRef.external.requested']({requestId:'r-fast-2',provider:'barilanfindref',query:'ברכות דף ב עמוד א'});
  await waitUntil(()=>replies.length===beforeReplies+1);
  const delta=calls.filter(x=>x.data?.url?.endsWith('/reference/open')).length-beforeCalls;
  assert.equal(delta,1);
  assert.equal(replies.find(r=>r.requestId==='r-fast-1'),undefined);

  // Leave room for the Otzar provider within the host's 100-hit limit.
  const beforeLimit = replies.length;
  matches = Array.from({length:100}, (_,i) => 'מקור בר אילן ' + i);
  events['findRef.external.requested']({requestId:'r-cap',provider:'barilanfindref',query:'מקורות רבים'});
  await waitUntil(()=>replies.length===beforeLimit+1);
  assert.equal(replies.at(-1).results.length,60);

  // 5. Old helper: suppress reference call to prevent accidental opens.
  health={service:'otzaria-responsa',apiVersion:1,capabilities:[]};
  missing = false;
  // Fresh runtime/context to clear cached port.
  const ev2={}, rp2=[]; let referenceCount=0;
  const ctx2={Otzaria:{on(k,v){ev2[k]=v},call(m,d){
    if(m==='reader.respondFindRef'){rp2.push(d);return {success:true};}
    if(d.url.endsWith('/reference/open'))referenceCount++;
    const x={type:'response',status:200};const y={type:'data',body:JSON.stringify(health)};
    return(async function*(){yield x;yield y})();
  }}, console};
  vm.createContext(ctx2);vm.runInContext(script,ctx2);
  ev2['findRef.external.requested']({requestId:'r2',provider:'barilanfindref',query:'בראשית א ב'});
  await waitUntil(()=>rp2.length===1);
  assert.equal(referenceCount,0);
  assert.equal(rp2[0].results.length,0);
  assert.match(rp2[0].error,/referenceResolve/);
  console.log('PASS: passive unique, checked open, reordered result, old-service guard');
})().catch(e=>{console.error(e);process.exitCode=1;});
