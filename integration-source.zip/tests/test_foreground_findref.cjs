'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const plugin = path.join(__dirname, '../plugin');
const html = fs.readFileSync(path.join(plugin, 'index.html'), 'utf8');
const nodes = { target: { value: 'local' }, save: { disabled: true }, status: {} };
const events = {}, replies = [], opened = [], writes = [];
let preference = 'local', save;
nodes.save.addEventListener = (_, fn) => { save = fn; };
const row = { book_id: 9679, title: 'מהר"ם שיק', authors: '["שיק, משה"]', places: 'סטו מרה', from_year: 'תר"צ' };
const context = vm.createContext({
  console,
  document: { getElementById: id => nodes[id], documentElement: { style: { setProperty() {} } } },
  Otzaria: {
    on(name, fn) { events[name] = fn; },
    async call(method, data) {
      if (method === 'storage.get') return { success: true, data: preference };
      if (method === 'storage.set') { preference = data.value; writes.push(preference); return { success: true }; }
      if (method === 'database.query') return { success: true, data: { rows: [row] } };
      if (method === 'reader.respondFindRef') { replies.push(data); return { success: true, data: true }; }
      assert.equal(method, 'network.fetchStream');
      let value;
      if (data.url.endsWith('/health')) {
        value = { service: 'otzaria-responsa', apiVersion: 1, capabilities: ['referenceResolve', 'otzarOpen'] };
      } else {
        assert.ok(data.url.endsWith('/otzar/open'));
        const chosen = JSON.parse(data.body);
        assert.equal(chosen.bookId, 9679);
        opened.push(chosen);
        value = { opened: true, target: 'local', bookId: 9679 };
      }
      return (async function* () {
        yield { type: 'response', status: 200 };
        yield { type: 'data', body: JSON.stringify(value) };
      })();
    },
  },
});
for (const match of html.matchAll(/<script\s+src="([^"]+)"\s*>/g)) {
  vm.runInContext(fs.readFileSync(path.join(plugin, match[1]), 'utf8'), context, { filename: match[1] });
}
async function flush() { for (let i = 0; i < 20; i++) await new Promise(resolve => setImmediate(resolve)); }
(async () => {
  events['plugin.ready']();
  await flush();
  assert.equal(nodes.save.disabled, false);
  nodes.target.value = 'online';
  await save();
  nodes.target.value = 'local';
  await save();
  assert.deepEqual(writes, ['online', 'local']);
  assert.equal(typeof events['findRef.external.requested'], 'function', 'Restored foreground page must handle provider requests when no background controller exists');
  events['findRef.external.requested']({ requestId: 'foreground-1', provider: 'catalogfindref', query: 'מהרם שיק' });
  await flush();
  assert.equal(replies.length, 1);
  assert.equal(replies[0].results.length, 1);
  assert.equal(opened.length, 0, 'Foreground search must remain passive');
  const chosen = replies[0].results[0];
  assert.match(chosen.reference, /9679/);
  events['findRef.external.openRequested']({ provider: 'catalogfindref', query: 'מהרם שיק', choiceIndex: chosen.choiceIndex, expectedChoice: chosen.reference });
  await flush();
  assert.equal(opened.length, 1, 'Exactly one chosen book is opened');
  console.log('PASS: restored foreground provider replies, settings coexist, passive search, exact single local opening');
})().catch(error => { console.error(error); process.exitCode = 1; });
