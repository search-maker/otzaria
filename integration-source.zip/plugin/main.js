// Background providers for the original Otzaria Find Sources dialog.
// Reads catalog metadata only; searching never opens a book.
// Requires referenceResolve; explicit local Otzar opening also needs otzarOpen.
const PROVIDER = 'barilanfindref';
const OTZAR_PROVIDER = 'catalogfindref';
const PORTS = Array.from({ length: 10 }, (_, i) => 39700 + i);
const SERVICE = 'otzaria-responsa';
let cachedPort = null;
let serial = Promise.resolve();
const seenRequests = new Map();
const cancelled = new Set();
const otzarSnapshots = new Map();

async function rpc(method, params) {
  const response = await Otzaria.call(method, params);
  if (response?.success === false) throw new Error(response.error?.code || 'Otzaria request failed');
  return response && Object.hasOwn(response, 'data') ? response.data : response;
}

function normalizedTitle(value) {
  return String(value || '').normalize('NFKD').replace(/\p{M}/gu, '')
    .replace(/["'\u05F3\u05F4]/g, '').replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim().toLowerCase();
}

function otzarLabel(row) {
  let authors = [];
  try { authors = JSON.parse(row.authors || '[]'); } catch (_) { /* Catalog metadata may be incomplete. */ }
  if (!Array.isArray(authors)) authors = [];
  const years = [...new Set([row.from_year, row.to_year].filter(Boolean))].join('–');
  const metadata = [authors.filter(s => typeof s === 'string').join(', '), row.places, years]
    .filter(Boolean).join(', ');
  const title = [String(row.title || '').trim(), metadata].filter(Boolean).join(' — ');
  return `${title.slice(0, 365)} (מס׳ ${row.book_id})`;
}

async function otzarRows(where, columns, limit) {
  const data = await rpc('database.query', {
    sourceId: 'external_catalog', from: { table: 'otzar_hahochma', alias: 'b' },
    select: columns.map(column => ({ expr: `b.${column}` })), where,
    orderBy: [{ expr: 'b.book_id', direction: 'asc' }], limit, rowFormat: 'object',
  });
  if (!Array.isArray(data?.rows)) throw new Error('Invalid catalog response');
  return data.rows.filter(r => Number.isSafeInteger(r.book_id) && r.book_id > 0 &&
    typeof r.title === 'string' && r.title.trim());
}

const otzarColumns = ['book_id', 'title', 'authors', 'places', 'from_year', 'to_year'];

async function findOtzar(query) {
  const normalized = normalizedTitle(query);
  if (normalized.length < 3 || normalized.length > 250) return [];
  const tokens = normalized.split(' ');
  // Wildcards between letters allow Hebrew quotes and vowel marks in titles.
  const rows = await otzarRows({ op: 'and', conditions: tokens.slice(0, 6).map(token => ({
    op: 'like', left: 'b.title', value: `%${[...token].join('%')}%`,
  })) }, ['book_id', 'title'], 1000);
  const rank = row => {
    const title = normalizedTitle(row.title);
    return title === normalized ? 0 : title.startsWith(normalized) ? 1 : 2;
  };
  const matches = rows.filter(row => tokens.every(token => normalizedTitle(row.title).includes(token)))
    .sort((a, b) => rank(a) - rank(b) || a.book_id - b.book_id).slice(0, 40);
  if (!matches.length) return [];
  const details = await otzarRows({ op: 'in', left: 'b.book_id', value: matches.map(r => r.book_id) }, otzarColumns, 40);
  const byId = new Map(details.map(row => [row.book_id, row]));
  return matches.flatMap(row => {
    const detail = byId.get(row.book_id);
    return detail ? [{ bookId: detail.book_id, reference: otzarLabel(detail) }] : [];
  });
}

async function handleOtzarSearch(payload) {
  const { requestId, query } = payload;
  if (typeof requestId !== 'string' || typeof query !== 'string' || seenRequests.has(requestId)) return;
  seenRequests.set(requestId, true);
  if (seenRequests.size > 500) seenRequests.clear();
  try {
    if (cancelled.has(requestId)) return;
    const results = await findOtzar(query);
    if (cancelled.has(requestId)) return;
    otzarSnapshots.delete(query);
    otzarSnapshots.set(query, results);
    if (otzarSnapshots.size > 32) otzarSnapshots.delete(otzarSnapshots.keys().next().value);
    await reply(requestId, results.map((result, choiceIndex) => ({ reference: result.reference, choiceIndex })));
  } catch (error) {
    console.error('Otzar lookup failed:', String(error));
    if (!cancelled.has(requestId)) await reply(requestId, [], String(error));
  } finally {
    cancelled.delete(requestId);
  }
}

async function handleOtzarOpen(payload) {
  if (typeof payload.query !== 'string' || typeof payload.expectedChoice !== 'string' ||
      !Number.isInteger(payload.choiceIndex) || payload.choiceIndex < 0 || payload.choiceIndex >= 40) return;
  const snapshot = otzarSnapshots.get(payload.query) || await findOtzar(payload.query);
  const chosen = snapshot[payload.choiceIndex];
  if (!chosen || chosen.reference !== payload.expectedChoice) throw new Error('Selection changed');
  const current = await otzarRows({ op: '=', left: 'b.book_id', value: chosen.bookId }, otzarColumns, 1);
  if (current.length !== 1 || otzarLabel(current[0]) !== payload.expectedChoice) throw new Error('Book changed');
  const savedTarget = await rpc('storage.get', { key: 'otzar_open_target' });
  const target = ['local', 'online', 'auto'].includes(savedTarget) ? savedTarget : 'local';
  if (target === 'local') {
    const port = await connection('otzarOpen');
    const response = await http(port, '/otzar/open', 'POST', { bookId: chosen.bookId, page: 1 });
    if (response.opened !== true || response.target !== 'local' || response.bookId !== chosen.bookId) {
      throw new Error('Local book could not be opened');
    }
    return;
  }
  const opened = target === 'online'
    ? await rpc('app.openUrl', { url: `https://tablet.otzar.org/book/book.php?book=${chosen.bookId}` })
    : await rpc('reader.openBook', { external: { provider: 'otzar', id: chosen.bookId } });
  if (opened !== true) throw new Error('Book could not be opened');
}

async function http(port, path, method = 'GET', data = undefined, timeoutMs = 12000) {
  let stream = await Otzaria.call('network.fetchStream', {
    url: `http://127.0.0.1:${port}${path}`,
    method,
    ...(data === undefined ? {} : {
      headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data),
    }),
    timeoutMs,
  });
  if (stream?.success === false) throw new Error('Local service request rejected by host');
  if (stream && !stream[Symbol.asyncIterator] && stream.data !== undefined) stream = stream.data;
  if (!stream?.[Symbol.asyncIterator]) throw new Error('Local service response is not a stream');
  let code = 0;
  let body = '';
  for await (const chunk of stream) {
    if (chunk.type === 'response') code = chunk.status;
    if (chunk.type === 'data') body += chunk.body;
  }
  if (!code || code >= 400) throw new Error(`HTTP ${code}: ${body.slice(0,200)}`);
  return JSON.parse(body || '{}');
}

async function connection(capability = 'referenceResolve') {
  const ports = cachedPort === null ? PORTS : [cachedPort, ...PORTS.filter(p => p !== cachedPort)];
  let oldHelper = false;
  for (const port of ports) {
    try {
      const health = await http(port, '/health', 'GET', undefined, 2500);
      if (health.service !== SERVICE || health.apiVersion !== 1) continue;
      if (!Array.isArray(health.capabilities) || !health.capabilities.includes(capability)) {
        // Never fall back to an old helper: it would OPEN a singleton result.
        oldHelper = true;
        continue;
      }
      cachedPort = port;
      return port;
    } catch (_) { /* The next loopback port may host this user's helper. */ }
  }
  cachedPort = null;
  throw new Error(oldHelper ? `Helper missing passive ${capability} capability`
    : 'Local Responsa service is unavailable');
}

function queue(task) {
  const result = serial.then(task);
  serial = result.catch(() => undefined);
  return result;
}

async function reply(requestId, results, error = null) {
  const response = await Otzaria.call('reader.respondFindRef', {
    requestId,
    results,
    ...(error ? { error: String(error).slice(0,200) } : {}),
  });
  return response;
}

async function handleSearch(payload) {
  if (payload?.provider === OTZAR_PROVIDER) return handleOtzarSearch(payload);
  if (!payload || payload.provider !== PROVIDER) return;
  const { requestId, query } = payload;
  if (typeof requestId !== 'string' || typeof query !== 'string') return;
  if (seenRequests.has(requestId)) return;
  seenRequests.set(requestId, true);
  if (seenRequests.size > 500) seenRequests.clear();
  return queue(async () => {
    try {
      if (cancelled.has(requestId)) return;
      if (query.trim().length < 3) return await reply(requestId, []);
      const port = await connection();
      // Passive: even a unique match must not be opened by searching.
      // autoStart:false avoids launching Responsa on every keystroke.
      if (cancelled.has(requestId)) return;
      const found = await http(port, '/reference/open', 'POST', {
        ref: query, listOnly: true, autoStart: false,
      }, 120000);
      if (cancelled.has(requestId)) return;
      const choices = Array.isArray(found.choices) && found.opened === false
        ? found.choices : [];
      return await reply(requestId, choices.slice(0,60).map((reference, choiceIndex) => ({
        reference: String(reference), choiceIndex,
      })));
    } catch (error) {
      if (!cancelled.has(requestId)) await reply(requestId, [], String(error));
    } finally {
      cancelled.delete(requestId);
    }
  });
}

async function handleOpen(payload) {
  if (payload?.provider === OTZAR_PROVIDER) return handleOtzarOpen(payload);
  if (!payload || payload.provider !== PROVIDER) return;
  if (typeof payload.query !== 'string' || typeof payload.expectedChoice !== 'string') return;
  const idx = payload.choiceIndex;
  if (!Number.isInteger(idx) || idx < 0 || idx >= 1000) return;
  return queue(async () => {
    const port = await connection();
    // expectedChoice is checked natively in the helper BEFORE opening.
    const res = await http(port, '/reference/open', 'POST', {
      ref: payload.query, index: idx, expectedChoice: payload.expectedChoice,
      autoStart: true, notify: true,
    }, 120000);
    if (res.opened === true) return;
    // If order changed, we can safely relocate by title and revalidate.
    const revised = Array.isArray(res.choices) ? res.choices : [];
    const newIndex = revised.findIndex(s => s === payload.expectedChoice);
    if (newIndex >= 0 && newIndex !== idx &&
        revised.filter(s => s === payload.expectedChoice).length === 1) {
      const retry = await http(port, '/reference/open', 'POST', {
        ref: payload.query, index: newIndex, expectedChoice: payload.expectedChoice,
        autoStart: true, notify: true,
      }, 120000);
      if (retry.opened === true) return;
    }
    throw new Error('המקור שנבחר השתנה או אינו זמין. יש לחפש ולבחור אותו מחדש.');
  });
}

Otzaria.on('findRef.external.cancelled', (payload) => {
  if (typeof payload?.requestId === 'string') cancelled.add(payload.requestId);
});
Otzaria.on('findRef.external.requested', (payload) => {
  void handleSearch(payload).catch(e => console.error('Bar Ilan reference reply failed:', e));
});
Otzaria.on('findRef.external.openRequested', (payload) => {
  void handleOpen(payload).catch(async e => {
    console.error('Bar Ilan open failed:', e);
    await Otzaria.call('ui.showError', {
      message: payload?.provider === OTZAR_PROVIDER
        ? 'לא ניתן לפתוח את הספר באוצר החכמה. בדקו שהתוכנה המקומית ושירות העזר פועלים, או שנו את יעד הפתיחה בהגדרות התוסף.'
        : 'לא ניתן לפתוח את המקור בבר אילן. ודאו שהשירות פועל וחפשו שוב.',
    });
  });
});
