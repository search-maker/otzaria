'use strict';
const targetControl = document.getElementById('target');
const saveControl = document.getElementById('save');
const statusControl = document.getElementById('status');
function applyTheme(theme) {
  if (!theme?.colorScheme) return;
  const style = document.documentElement.style;
  const colors = theme.colorScheme;
  const roles = {
    '--color-background': theme.surfaces?.panel || colors.surface,
    '--color-control-background': theme.surfaces?.card || colors.surfaceContainer || colors.surface,
    '--color-text': colors.onSurface,
    '--color-border': colors.outline,
  };
  for (const [name, value] of Object.entries(roles)) {
    if (typeof value === 'string') style.setProperty(name, value);
  }
  style.colorScheme = theme.mode === 'dark' ? 'dark' : 'light';
  if (typeof theme.typography?.uiFont === 'string') {
    style.setProperty('--font-base', theme.typography.uiFont);
  }
  if (Number.isFinite(theme.radius) && theme.radius >= 0) {
    style.setProperty('--radius', `${theme.radius}px`);
  }
}
Otzaria.on('plugin.boot', payload => applyTheme(payload?.theme));
Otzaria.on('theme.changed', applyTheme);
async function settingsCall(method, params) {
  const response = await Otzaria.call(method, params);
  if (response?.success === false) throw new Error('Settings request failed');
  return response && Object.hasOwn(response, 'data') ? response.data : response;
}
Otzaria.on('plugin.ready', () => {
  void settingsCall('storage.get', { key: 'otzar_open_target' }).then(value => {
    targetControl.value = ['local', 'online', 'auto'].includes(value) ? value : 'local';
    saveControl.disabled = false;
    statusControl.textContent = '';
  }).catch(() => { statusControl.textContent = 'לא ניתן לטעון את ההגדרה. נסו לפתוח את התוסף מחדש.'; });
});
saveControl.addEventListener('click', async () => {
  saveControl.disabled = true;
  try {
    await settingsCall('storage.set', { key: 'otzar_open_target', value: targetControl.value });
    statusControl.textContent = 'ההגדרה נשמרה. הבחירה תחול על הספר הבא שתפתחו.';
  } catch (_) {
    statusControl.textContent = 'לא ניתן לשמור את ההגדרה. נסו שוב.';
  } finally {
    saveControl.disabled = false;
  }
});
