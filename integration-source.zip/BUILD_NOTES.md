# Source changes and reproducibility

Otzaria upstream: https://github.com/Otzaria/otzaria
Base commit: ea1f00d20edb723d69cd099c95e5db4304b9394b

The installed prototype runtime uses that base. A separate review patch,
`otzaria-native-findref-upstream.patch`, applies to current dev commit
`9428dceb2c725cf02a4cf46badb1eaacec047b0a` without the prototype version bump.
Flutter analysis passes on that review branch; its focused test result is recorded
separately. Do not confuse the review base with the already built host executable.

Responsa helper upstream: https://github.com/mmichaelush/otzaria-responsa-plugin
Base commit: 4c1fd6ed3862aa6f120c421d0e3b1092f3c43b28

Apply the corresponding patch with `git apply` in each clean base checkout. The patches include new files and tests. No commercial Responsa binary is changed.

The companion's source is in `plugin/`; run `node tests/test_companion.cjs` from this folder. Results appear in the original native Find Sources dialog. Its separate tool page contains opening preferences only.

Companion 0.3.0 contributes `barilanfindref` and `catalogfindref`. It uses the read-only `external_catalog` database API for Otzar title lookup. It returns at most 60 Responsa references and 40 Otzar books within the host's shared 100-result allowance. Otzar entries identify the edition by title, author, place, year and immutable catalog ID; opening revalidates the selected record. This is a book-title lookup, not citation-to-page inference.

The settings page persists `otzar_open_target`: `local` (default), `online`, or `auto`. Local calls the helper's narrow `otzarOpen` capability and `POST /otzar/open` with the exact catalog ID; it never falls back to a website on failure. Online calls `app.openUrl` with a fixed HTTPS Otzar book URL. Auto retains the existing host `reader.openBook({external:{provider:'otzar',id}})` behavior. Only explicit selection opens a book. The helper discovers the existing local executable through `OTZARAPPCD`, or the legacy fixed installation; it accepts no executable path from clients. The legacy viewer supports page 1 only and rejects other pages explicitly. Helper API version remains 1; existing endpoints remain compatible.

Additional plugin tests: `node tests/test_otzar_findref.cjs` and `node tests/test_otzar_settings.cjs`. The read-only real-catalog test is `node tests/test_otzar_catalog_live.cjs <python.exe> <otzar-HB_catalog.db>`; this verifies actual catalog data but stubs reader opening, so it does not replace a live GUI click test. The standalone `.otzplugin` requires a host supporting `reader.respondFindRef` and `libraryBooks.referenceSearch`; an unmodified host needs the native patch first. Companion 0.3.0 requires helper 0.8.2 for explicit local opening; Bar-Ilan passive lookup requires `referenceResolve`.

Build environment used: Windows x64, Flutter 3.47.9 / Dart 3.13.7, Visual Studio 2022 Build Tools 17.14, Windows SDK 10.0.26100, JDK 21, Rust 1.99.1 and Microsoft's signed NuGet CLI. Git dependencies remain pinned in the original lockfile. Enable Git core.longpaths when restoring Windows package caches. After repairing an incomplete cache, rerun `flutter pub get` so generated Windows plugin registration includes flutter_inappwebview_windows.

Otzaria: `flutter pub get`, `flutter analyze --no-pub`, `flutter test --no-pub --concurrency=1`, `flutter build windows --release --no-pub`.

Helper, from `helper/`: `dart pub get`, `dart analyze --fatal-infos`, `dart test --concurrency=1`, `dart build cli`. The live test is opt-in: set FINDREF_LIVE=1 and run `dart test test/live_native_findref_http_test.dart --run-skipped`; it expects the new helper on port 39709 and an already running licensed Responsa instance. It intentionally opens one selected source at the end.

The final 0.8.2 helper uses Dart 3.13.7, matching the original validated build. Mark it as a Windows GUI subsystem using the helper repository's `tools/set_gui_subsystem.py`, so logon startup does not display a console. The complete CLI bundle, including `lib/sqlite3.dll`, is required. The compiled-binary catalog preservation check compares all 15,474 existing records. The full helper suite passes 632 tests with 16 opt-in skips. Installation tests inject drive/process discovery to avoid reading the real mounted commercial media; production discovery defaults remain unchanged. The logger now supplies the required bytes-written output pointer to synchronous Win32 WriteFile.

Native crash investigation found the same `FlutterPlatformNodeDelegate::ChildAtIndex+0x3f` null-child dereference in three minidumps. Matching official symbols and the engine DLL SHA-256 confirmed engine revision `89c39edfdfae2949f6806e4a315c0c08522238b7` (Flutter 3.47.9), matching upstream Flutter issue 195399. `flutter-engine-accessibility.patch` adds a missing-child check and a native regression test; it changes no commercial application. Build from the same engine revision after `gclient sync` and hooks: `python flutter/tools/gn --runtime-mode=release --windows-cpu=x64 --no-goma --no-lto --enable-unittests`, then `ninja -C out/host_release -j3 flutter_windows.dll common_cpp_unittests.exe` from `engine/src`. Windows SDK Debugging Tools and Microsoft ATL are required. This machine uses SDK 10.0.26100.0; the engine build dependency's pinned SDK version must match the installed SDK. Keep the matching PDB for any custom engine build. Native regression and live stability results are reported separately; preparation of this patch alone is not proof of a fixed installation.

This machine's filtered network required verified downloads of PDFium 7811 and ONNX Runtime 1.28.0 via official GitHub release assets. A local isolated copy of Microsoft's ATL 14.44 headers/libraries supplied the missing ATL component. Cargo HTTP revocation checking was disabled only in the isolated build tool directory because the network's revocation lookup failed; certificate validation and crate checksums stayed enabled. No such build configuration is required to run the resulting binaries.

The final engine patch also prunes pending accessibility updates unreachable in the
effective next tree. A late update for a removed overlay previously froze the live
AXTree. DetachedUpdateDoesNotFreezeTree fails without this fix and passes with it;
all 232 native tests pass alongside MissingChildReturnsNull. The packaged engine
SHA-256 is 8dbb7b206174dbd65ac2bfab469646d447b3f2e066755f3fedf2728c27d108e2.
The companion foreground page loads main.js as well as settings.js: event dispatch
prefers the background controller but can fall back to the restored foreground.
Run tests/test_foreground_findref.cjs for this regression. Only one controller
receives a dispatched event, so this does not duplicate opening.

The Windows bundle includes Microsoft's VC143 CRT DLLs from the installed Build Tools redistributables and the x64 WebView2 loader matching NuGet's Microsoft.Web.WebView2 1.0.4078.44 package. Git Bash is needed on PATH for upstream shell-based packaging tests. Tests that inspect removable installations also detect this machine's real mounted Responsa media; their known baseline failures are listed in the test report.
